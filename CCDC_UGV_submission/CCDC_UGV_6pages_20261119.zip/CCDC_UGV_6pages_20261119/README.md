# CCDC UGV 六页英文论文与 MATLAB 配套资料

## 最终提交文件

- `paper/CCDC_Shugang_Zhang_6pages.pdf`：已核验为 **6 页**的固定版面英文论文。
- `paper/CCDC_Shugang_Zhang_6pages.docx`：可编辑 Word 稿，采用所给会议模板，无致谢。
- `matlab/UGV_CCDC_Reproduce.m`：完整主程序（含全部 25 个局部函数），建议在 MATLAB R2016b 或更新版本中整体运行。

## 程序运行

1. 解压到可写文件夹。
2. 在 MATLAB 中进入 `matlab` 文件夹，打开 `UGV_CCDC_Reproduce.m`。
3. 点击“运行”，或在命令窗口输入 `UGV_CCDC_Reproduce`。不要只复制前若干行。
4. 程序训练三种 Q 策略并完成 20 次独立试验，可能需要一定时间。随后输出 CSV、MAT，以及 `figures` 子文件夹中的三幅图的 PNG/PDF。

主程序保留原训练、路径规划和评价逻辑；新增部分只做实际结果汇总、图形显示/导出，以及由实际 LOS 前后数组生成第 3 幅对比图。原英文显示版另附为 `UGV_Original_English_Labels.m`。

## 资料目录

- `figures`：原始两幅仿真图（逐字节保持不变）及新增 LOS 消融图。
- `data`：论文采用的既有记录及明确的数据来源；不包含虚构的新试验数据。
- `sources`：本次上传的会议模板、中英文原稿，以及此前上传的完整原始 MATLAB 程序。
- `equations`：14 个显示公式的 TNR 矢量 PDF。
- `documentation`：排版核对、程序改动核对、已核实文献元数据。
- `SHA256SUMS.txt`：包内文件校验值。

## 证据范围

原始图和单次统计保留；新增 LOS 图是对同一路径已有前后记录的可视化。20 次日志采用不含可选平均平滑的辅助流程，论文已单独说明。BFS 回退属于最终可行性判定的一部分。当前环境未安装 MATLAB/Octave，因此未把静态语法检查表述为新的实跑验证。

GitHub 下载：打开 ZIP 文件页面后点击 **Download raw file / 下载原始文件**（下载箭头），下载后解压。
