# Data provenance

The single-run records and original two figures come from the uploaded Chinese/English manuscripts. The paired LOS records are the same repaired path before/after LOS, as reported in those manuscripts. The 20-trial aggregate comes from the MATLAB execution log supplied in the conversation; individual trial arrays and the original MAT workspace were not uploaded. No synthetic per-trial data are included.

The repeated block omits optional averaging, whereas the displayed single-run complete method includes accepted averaging. These protocols are therefore explicitly separated in the paper. The no-inflation configuration also omits averaging and LOS, so it is not a matched inflation-only ablation.

Fig3 is a new visualization of the recorded paired LOS comparison, not a newly executed stochastic experiment. Running the main MATLAB script computes and exports fresh metrics and the corresponding third figure from actual path arrays; paper values are not hard-coded into the simulator.
