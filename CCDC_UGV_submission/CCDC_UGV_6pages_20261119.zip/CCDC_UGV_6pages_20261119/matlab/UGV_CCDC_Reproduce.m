%% UGV path planning: heading-aware Q-learning + density-adaptive APF + LOS shortcut
% MATLAB R2016b or later; no additional toolbox required.
% Includes explicit legend handles, turn-angle metrics, collision-checked LOS
% shortcut and 20 independent proposed-method trials.
% MATLAB R2016b or later; no additional toolbox required.
% This is a corrected/revised research simulation, not a validated real-vehicle controller.
% Obstacle rectangles are reconstructed from the previously supplied 20x20 map.
clear; clc; close all; rng(14);

%% 1. Map and vehicle safety model
N = 20;
startRC = [1 1];
goalRC  = [20 20];

% [x_min x_max y_min y_max], where x=column and y=row
rectXY = [3 4 3 4; 5 7 12 13; 8 9 7 9; 10 11 10 11; ...
          12 14 15 16; 14 15 6 7; 16 17 13 14; 17 18 3 4; 3 4 17 18];

occ = false(N,N);
for k = 1:size(rectXY,1)
    occ(rectXY(k,3):rectXY(k,4), rectXY(k,1):rectXY(k,2)) = true;
end
occ(startRC(1),startRC(2)) = false;
occ(goalRC(1),goalRC(2)) = false;

% Configuration-space inflation: effective vehicle radius + safety margin
vehicleRadius = 0.45;
safetyMargin  = 0.55;
inflationRadius = vehicleRadius + safetyMargin;
occPlan = inflateObstacles(occ,inflationRadius);
occPlan(startRC(1),startRC(2)) = false;
occPlan(goalRC(1),goalRC(2)) = false;

% Critical preflight test: do not continue if the map itself is infeasible.
testPath = bfsPath(startRC,goalRC,occPlan);
if isempty(testPath)
    error(['No collision-free route exists after obstacle inflation. ', ...
           'Reduce vehicleRadius/safetyMargin or revise the map.']);
end
fprintf('Map check passed: inflated-map BFS path has %d nodes.\n',size(testPath,1));

%% 2. Q-learning parameters
actions = [-1 0; 1 0; 0 -1; 0 1; -1 -1; -1 1; 1 -1; 1 1];
nEpisode = 2000;
maxStep = 500;
alpha = 0.15;
gamma = 0.95;
epsilon0 = 1.0;
epsilonMin = 0.03;
epsilonDecay = 0.996;
Rgoal = 100;
Rcollision = -25;
Rstep = -1;
progressGain = 2.0;
headingPenalty = 3.0;
curveWindow = 120;

%% 3. Train baseline and heading-aware Q-learning
fprintf('\nTraining baseline Q-learning...\n');
[Q0,log0] = trainQ(occPlan,startRC,goalRC,actions,nEpisode,maxStep, ...
    alpha,gamma,epsilon0,epsilonMin,epsilonDecay,Rgoal,Rcollision, ...
    Rstep,progressGain,0);

fprintf('Training heading-aware Q-learning...\n');
[Qh,logH] = trainQ(occPlan,startRC,goalRC,actions,nEpisode,maxStep, ...
    alpha,gamma,epsilon0,epsilonMin,epsilonDecay,Rgoal,Rcollision, ...
    Rstep,progressGain,headingPenalty);

fprintf('Training no-inflation ablation...\n');
[Qraw,logRaw] = trainQ(occ,startRC,goalRC,actions,nEpisode,maxStep, ...
    alpha,gamma,epsilon0,epsilonMin,epsilonDecay,Rgoal,Rcollision, ...
    Rstep,progressGain,headingPenalty);

%% 4. Extract policies; record whether BFS fallback was needed
[basePath,baseFallback] = policyOrBFS(Q0,occPlan,startRC,goalRC,actions,false);
[qPath,qFallback] = policyOrBFS(Qh,occPlan,startRC,goalRC,actions,true);
[rawPath,rawFallback] = policyOrBFS(Qraw,occ,startRC,goalRC,actions,true);

fprintf('\nPolicy extraction: baseline fallback=%d, heading-Q fallback=%d, no-inflation fallback=%d\n', ...
    baseFallback,qFallback,rawFallback);

%% 5. APF local replanning and proposed method
dangerDist = 1.6;
kAtt = 1.0;
kRep = 18.0;
rho0 = 3.0;
goalPower = 2;
apfStep = 0.25;
apfMaxIter = 2500;
densityGain = 2.0;

pathQAPF = hybridReplan(basePath,occPlan,occ,false,dangerDist, ...
    kAtt,kRep,rho0,goalPower,apfStep,apfMaxIter,densityGain);
pathHQAPF = hybridReplan(qPath,occPlan,occ,false,dangerDist, ...
    kAtt,kRep,rho0,goalPower,apfStep,apfMaxIter,densityGain);
pathProposed = hybridReplan(qPath,occPlan,occ,true,dangerDist, ...
    kAtt,kRep,rho0,goalPower,apfStep,apfMaxIter,densityGain);
pathNoInflation = hybridReplan(rawPath,occ,occ,true,dangerDist, ...
    kAtt,kRep,rho0,goalPower,apfStep,apfMaxIter,densityGain);

% Safety-preserving smoothing: retain the candidate only when all segments are safe.
pathProposed = safeSmooth(pathProposed,occPlan,1);
pathProposedBeforeLOS = pathProposed;
% Greedy line-of-sight shortcut: remove intermediate nodes only when the
% complete connecting segment is collision-free in the inflated map.
pathProposed = lineOfSightShortcut(pathProposed,occPlan);
if ~validRoute(pathProposed,startRC,goalRC,occPlan)
    warning('LOS shortcut result failed validation; reverting to pre-LOS path.');
    pathProposed = pathProposedBeforeLOS;
end

% Final validity checks. Never report an empty/one-point path as a successful route.
if ~validRoute(pathProposed,startRC,goalRC,occPlan)
    warning('Proposed APF route failed validation; replacing it with a verified BFS route.');
    pathProposed = testPath;
end
if ~validRoute(pathQAPF,startRC,goalRC,occPlan), pathQAPF = bfsPath(startRC,goalRC,occPlan); end
if ~validRoute(pathHQAPF,startRC,goalRC,occPlan), pathHQAPF = bfsPath(startRC,goalRC,occPlan); end
if ~validRoute(basePath,startRC,goalRC,occPlan), basePath = testPath; end
if ~validRoute(pathNoInflation,startRC,goalRC,occ), pathNoInflation = bfsPath(startRC,goalRC,occ); end

%% 6. Metrics and transparent fallback reporting
paths = {basePath,pathQAPF,pathHQAPF,pathProposed,pathNoInflation};
names = {'Q-learning','Q-learning + standard APF', 'Heading-constrained Q-learning + standard APF', ...
         'Proposed Heading-Q + adaptive APF + LOS','Ablation: no obstacle inflation'};
checkMaps = {occPlan,occPlan,occPlan,occPlan,occ};

pathLen = zeros(5,1);
turns = zeros(5,1);
totalTurnDeg = zeros(5,1);
maxTurnDeg = zeros(5,1);
clearance = nan(5,1);
safe = false(5,1);
for i = 1:5
    pathLen(i) = pathLength(paths{i});
    turns(i) = turnCount(paths{i});
    totalTurnDeg(i) = totalTurningAngle(paths{i});
    maxTurnDeg(i) = maximumTurningAngle(paths{i});
    clearance(i) = minClearance(paths{i},occ);
    safe(i) = validRoute(paths{i},startRC,goalRC,checkMaps{i});
    fprintf('%s: length=%.3f, turns=%d, total turn=%.1f deg, max turn=%.1f deg, min clearance=%.3f, safe=%d\n', ...
        names{i},pathLen(i),turns(i),totalTurnDeg(i),maxTurnDeg(i),clearance(i),safe(i));
end

fallbackFlag = [baseFallback; baseFallback; qFallback; qFallback; rawFallback];
T = table((1:5)',names',pathLen,turns,totalTurnDeg,maxTurnDeg,clearance,safe,fallbackFlag, ...
    'VariableNames',{'AlgorithmID','Algorithm','PathLength','TurnCount', ...
    'TotalTurningAngleDeg','MaxTurningAngleDeg','MinClearance','CollisionFree','QPolicyFallbackToBFS'});
disp(T);
writetable(T,'UGV_path_metrics.csv');
losBeforeLength = pathLength(pathProposedBeforeLOS);
losAfterLength = pathLength(pathProposed);
losBeforeTurns = turnCount(pathProposedBeforeLOS);
losAfterTurns = turnCount(pathProposed);
LOSComparison = table(losBeforeLength,losAfterLength,losBeforeTurns,losAfterTurns, ...
    'VariableNames',{'LengthBeforeLOS','LengthAfterLOS','TurnsBeforeLOS','TurnsAfterLOS'});
disp('LOS shortcut before/after comparison:'); disp(LOSComparison);
writetable(LOSComparison,'UGV_LOS_comparison.csv');
save('UGV_simulation_results.mat','occ','occPlan','basePath','qPath','rawPath', ...
    'pathQAPF','pathHQAPF','pathProposed','pathProposedBeforeLOS','pathNoInflation','log0','logH', ...
    'logRaw','T','LOSComparison','fallbackFlag','inflationRadius','headingPenalty');

%% 6.5 Repeated-run robustness test for the proposed method
% This block retrains the heading-aware learner with independent seeds.
% It records actual results; no performance values are hard-coded.
nRepeat = 20;
mcLength = nan(nRepeat,1);
mcTurns = nan(nRepeat,1);
mcTurnAngle = nan(nRepeat,1);
mcClearance = nan(nRepeat,1);
mcSuccess = false(nRepeat,1);
baseSeed = 100;
fprintf('\nRunning %d independent proposed-method trials...\n',nRepeat);
for rep=1:nRepeat
    rng(baseSeed+rep);
    [Qrep,~] = trainQ(occPlan,startRC,goalRC,actions,nEpisode,maxStep, ...
        alpha,gamma,epsilon0,epsilonMin,epsilonDecay,Rgoal,Rcollision, ...
        Rstep,progressGain,headingPenalty);
    [pRep,~] = policyOrBFS(Qrep,occPlan,startRC,goalRC,actions,true);
    pRep = hybridReplan(pRep,occPlan,occ,true,dangerDist,kAtt,kRep,rho0, ...
        goalPower,apfStep,apfMaxIter,densityGain);
    if isempty(pRep) || ~validRoute(pRep,startRC,goalRC,occPlan)
        pRep = bfsPath(startRC,goalRC,occPlan);
    end
    pRep = lineOfSightShortcut(pRep,occPlan);
    mcSuccess(rep) = validRoute(pRep,startRC,goalRC,occPlan);
    if mcSuccess(rep)
        mcLength(rep)=pathLength(pRep);
        mcTurns(rep)=turnCount(pRep);
        mcTurnAngle(rep)=totalTurningAngle(pRep);
        mcClearance(rep)=minClearance(pRep,occ);
    end
end
MCResults = table((1:nRepeat)',mcSuccess,mcLength,mcTurns,mcTurnAngle,mcClearance, ...
    'VariableNames',{'Trial','Success','PathLength','TurnCount','TotalTurningAngleDeg','MinClearance'});
writetable(MCResults,'UGV_proposed_20run_results.csv');
validMC = mcSuccess & isfinite(mcLength);
if any(validMC)
    fprintf('Proposed method success rate: %.1f%% (%d/%d)\n',100*mean(mcSuccess),sum(mcSuccess),nRepeat);
    fprintf('Mean path length=%.3f +/- %.3f\n',mean(mcLength(validMC)),std(mcLength(validMC)));
    fprintf('Mean turns=%.2f +/- %.2f\n',mean(mcTurns(validMC)),std(mcTurns(validMC)));
    fprintf('Mean total turn angle=%.2f +/- %.2f deg\n',mean(mcTurnAngle(validMC)),std(mcTurnAngle(validMC)));
else
    warning('No valid Monte-Carlo trial; inspect map and planner parameters.');
end

save('UGV_simulation_results.mat','occ','occPlan','basePath','qPath','rawPath', ...
    'pathQAPF','pathHQAPF','pathProposed','pathProposedBeforeLOS','pathNoInflation', ...
    'log0','logH','logRaw','T','LOSComparison','MCResults','fallbackFlag', ...
    'inflationRadius','headingPenalty');
fprintf('Saved metrics, LOS comparison, 20-run results and MAT workspace.\\n');

%% 7. Training curves: raw records and moving-average trends
figure('Color','w','Name','Training Curves','Position',[100 80 950 780]);
subplot(3,1,1);
plot(logH.reward,'Color',[0.82 0.86 0.94]); hold on;
plot(smoothCurve(logH.reward,curveWindow),'b','LineWidth',2);
grid on; xlabel('Training episode'); ylabel('Cumulative return');
title('Heading-constrained Q-learning: cumulative return per episode'); legend('Raw data','Moving average');

subplot(3,1,2);
successPct = double(logH.success)*100;
plot(successPct,'Color',[0.96 0.84 0.84]); hold on;
plot(smoothCurve(successPct,curveWindow),'r','LineWidth',2);
grid on; ylim([-3 103]); xlabel('Training episode'); ylabel('Success rate (%)');
title('Training success rate'); legend('Raw data','Moving average');

subplot(3,1,3);
plot(logH.steps,'Color',[0.84 0.91 0.84]); hold on;
plot(smoothCurve(logH.steps,curveWindow),'Color',[0.05 0.48 0.16],'LineWidth',2);
grid on; xlabel('Training episode'); ylabel('Steps');
title('Steps per episode (failed episodes assigned maximum steps)'); legend('Raw data','Moving average');

%% 8. Path comparison (explicit handles fix legend ordering)
figure('Color','w','Name','UGV Path Planning Comparison','Position',[120 100 1050 760]);
drawMap(occ,occPlan); hold on;
hBase = plot(basePath(:,2),basePath(:,1),'Color',[0.20 0.45 0.85],'LineWidth',1.6);
hQAPF = plot(pathQAPF(:,2),pathQAPF(:,1),'Color',[0.95 0.55 0.10],'LineWidth',1.8);
hHQAPF = plot(pathHQAPF(:,2),pathHQAPF(:,1),'Color',[0.55 0.25 0.75],'LineWidth',1.8);
hProposed = plot(pathProposed(:,2),pathProposed(:,1),'r-','LineWidth',2.5);
hNoInflation = plot(pathNoInflation(:,2),pathNoInflation(:,1),'k--','LineWidth',1.5);
hStart = plot(startRC(2),startRC(1),'gp','MarkerFaceColor','g','MarkerSize',12);
hGoal = plot(goalRC(2),goalRC(1),'h','MarkerFaceColor',[1 .75 0],'MarkerSize',12);
legend([hBase,hQAPF,hHQAPF,hProposed,hNoInflation,hStart,hGoal], ...
    {'Q-learning','Q-learning + standard APF', 'Heading-constrained Q-learning + standard APF', ...
     'Proposed method (adaptive APF + LOS optimization)','Ablation (no obstacle inflation)','Start','Goal'}, ...
    'Location','eastoutside');
title('Comparison of UGV path planning results'); xlabel('Grid column coordinate'); ylabel('Grid row coordinate'); hold off;

fprintf('\nSaved UGV_path_metrics.csv and UGV_simulation_results.mat in current folder.\n');
fprintf('NOTE: QPolicyFallbackToBFS=1 means the Q policy did not yield a complete route; the displayed route is BFS fallback.\n');

%% 9. Reproducibility outputs (reporting/export only; planner unchanged)
% These additional files are computed from the simulation results above.
% No reference performance values are inserted into the calculation.
summaryTrialCount = nRepeat;
summarySuccessCount = sum(mcSuccess);
summarySuccessRatePct = 100*mean(mcSuccess);
summaryLengthMean = NaN;
summaryLengthStd = NaN;
summaryTurnsMean = NaN;
summaryTurnsStd = NaN;
summaryAngleMean = NaN;
summaryAngleStd = NaN;
summaryClearanceMean = NaN;
summaryClearanceStd = NaN;
if any(validMC)
    summaryLengthMean = mean(mcLength(validMC));
    summaryLengthStd = std(mcLength(validMC));
    summaryTurnsMean = mean(mcTurns(validMC));
    summaryTurnsStd = std(mcTurns(validMC));
    summaryAngleMean = mean(mcTurnAngle(validMC));
    summaryAngleStd = std(mcTurnAngle(validMC));
    summaryClearanceMean = mean(mcClearance(validMC));
    summaryClearanceStd = std(mcClearance(validMC));
end
MCSummary = table(summaryTrialCount,summarySuccessCount,summarySuccessRatePct, ...
    summaryLengthMean,summaryLengthStd,summaryTurnsMean,summaryTurnsStd, ...
    summaryAngleMean,summaryAngleStd,summaryClearanceMean,summaryClearanceStd, ...
    'VariableNames',{'Trials','Successes','EndToEndSuccessRatePct', ...
    'MeanPathLength','StdPathLength','MeanTurnCount','StdTurnCount', ...
    'MeanTotalTurningAngleDeg','StdTotalTurningAngleDeg', ...
    'MeanMinClearance','StdMinClearance'});
writetable(MCSummary,'UGV_proposed_20run_summary.csv');
save('UGV_simulation_results.mat','MCSummary','-append');

figureFolder = fullfile(pwd,'figures');
if ~exist(figureFolder,'dir'), mkdir(figureFolder); end
% Additional within-path ablation display; uses the values computed above.
% This does not retrain a policy or change the two original figure contents.
figure('Color','w','Name','LOS Ablation','Units','inches', ...
    'Position',[1 1 3.3791667 2.1]);
subplot(1,2,1);
bar(1,losBeforeLength,'FaceColor',[0.55 0.55 0.55]); hold on;
bar(2,losAfterLength,'FaceColor',[0.20 0.45 0.85]); hold off;
set(gca,'XTick',[1 2],'XTickLabel',{'Without LOS','With LOS'});
title('Path length'); ylabel('Length (cells)');
ylim([0 1.35*max([1 losBeforeLength losAfterLength])]);
if losBeforeLength > 0
    lengthReductionPct = 100*(losBeforeLength-losAfterLength)/losBeforeLength;
    lengthReductionLabel = sprintf('Reduction: %.2f%%',lengthReductionPct);
else
    lengthReductionLabel = 'Reduction: n/a';
end
text(0.5,0.95,lengthReductionLabel,'Units','normalized', ...
    'HorizontalAlignment','center','VerticalAlignment','top');
subplot(1,2,2);
bar(1,losBeforeTurns,'FaceColor',[0.55 0.55 0.55]); hold on;
bar(2,losAfterTurns,'FaceColor',[0.20 0.45 0.85]); hold off;
set(gca,'XTick',[1 2],'XTickLabel',{'Without LOS','With LOS'});
title('Turn count'); ylabel('Turns');
ylim([0 1.35*max([1 losBeforeTurns losAfterTurns])]);
if losBeforeTurns > 0
    turnsReductionPct = 100*(losBeforeTurns-losAfterTurns)/losBeforeTurns;
    turnsReductionLabel = sprintf('Reduction: %.2f%%',turnsReductionPct);
else
    turnsReductionLabel = 'Reduction: n/a';
end
text(0.5,0.95,turnsReductionLabel,'Units','normalized', ...
    'HorizontalAlignment','center','VerticalAlignment','top');

figureHandles = findall(groot,'Type','figure');
for figureIndex = 1:numel(figureHandles)
    exportHandle = figureHandles(figureIndex);
    % Display/export formatting only; no path or training data are changed.
    fontNameObjects = findall(exportHandle,'-property','FontName');
    fontSizeObjects = findall(exportHandle,'-property','FontSize');
    set(fontNameObjects,'FontName','Times New Roman');
    set(fontSizeObjects,'FontSize',8);
    oldDisplayUnits = get(exportHandle,'Units');
    set(exportHandle,'Units','inches');
    displayPosition = get(exportHandle,'Position');
    if strcmp(get(exportHandle,'Name'),'LOS Ablation')
        exportWidthInches = 3.3791667;
        exportHeightInches = 2.1;
    else
        exportWidthInches = 6.9;
        exportHeightInches = exportWidthInches*displayPosition(4)/displayPosition(3);
    end
    set(exportHandle,'Position',[displayPosition(1:2) exportWidthInches exportHeightInches]);
    set(exportHandle,'Units',oldDisplayUnits);
    figureName = get(exportHandle,'Name');
    if strcmp(figureName,'Training Curves')
        figureStem = 'Fig2_Training_Curves';
    elseif strcmp(figureName,'UGV Path Planning Comparison')
        figureStem = 'Fig1_UGV_Path_Comparison';
    elseif strcmp(figureName,'LOS Ablation')
        figureStem = 'fig3_los_ablation';
    else
        figureStem = sprintf('Figure_%d',figureIndex);
    end
    pngFile = fullfile(figureFolder,[figureStem '.png']);
    pdfFile = fullfile(figureFolder,[figureStem '.pdf']);
    exported = false;
    if exist('exportgraphics','file') == 2
        try
            exportgraphics(exportHandle,pngFile,'Resolution',300);
            exportgraphics(exportHandle,pdfFile,'ContentType','vector');
            exported = true;
        catch exportError
            warning('ExportGraphics failed; using print: %s',exportError.message);
        end
    end
    if ~exported
        oldFigureUnits = get(exportHandle,'Units');
        set(exportHandle,'Units','inches');
        exportPosition = get(exportHandle,'Position');
        set(exportHandle,'Units',oldFigureUnits);
        set(exportHandle,'PaperUnits','inches', ...
            'PaperSize',exportPosition(3:4), ...
            'PaperPosition',[0 0 exportPosition(3:4)]);
        print(exportHandle,pngFile,'-dpng','-r300');
        print(exportHandle,pdfFile,'-dpdf','-painters');
    end
end
fprintf('Saved a computed 20-run summary and English PDF/PNG figures in %s.\n',figureFolder);

%% =============================== Local functions ===============================

function [Q,L] = trainQ(occ,s,g,act,ne,ms,alpha,gamma,e0,emin,ed,rg,rc,rs,progressGain,lambda)
[nr,nc] = size(occ);
headingOn = lambda > 0;
if headingOn, nH = 8; else, nH = 1; end
Q = zeros(nr*nc*nH,8);
L.reward = zeros(ne,1);
L.success = false(ne,1);
L.steps = ms*ones(ne,1);
epsNow = e0;

for ep = 1:ne
    p = s;
    h = initialHeading(s,g,act);
    total = 0;
    for t = 1:ms
        sid = stateID(p,h,nr,nc,headingOn);
        if rand < epsNow
            ai = randi(8);
        else
            qv = Q(sid,:);
            candidates = find(qv == max(qv));
            ai = candidates(randi(numel(candidates)));
        end

        pn = p + act(ai,:);
        reward = rs;
        validMove = true;
        if pn(1)<1 || pn(1)>nr || pn(2)<1 || pn(2)>nc
            validMove = false;
        elseif occ(pn(1),pn(2))
            validMove = false;
        else
            dr = pn(1)-p(1); dc = pn(2)-p(2);
            if dr~=0 && dc~=0 && (occ(p(1)+dr,p(2)) || occ(p(1),p(2)+dc))
                validMove = false;
            end
        end

        if ~validMove
            pn = p;
            reward = rc;
            h2 = h;
        else
            dBefore = norm(double(g-p));
            dAfter = norm(double(g-pn));
            reward = reward + progressGain*(dBefore-dAfter);
            h2 = ai;
            if headingOn && h>0
                dtheta = abs(wrapPi(actionAngle(act(ai,:))-actionAngle(act(h,:))));
                reward = reward - lambda*dtheta/pi;
            end
            if isequal(pn,g), reward = reward + rg; end
        end

        sid2 = stateID(pn,h2,nr,nc,headingOn);
        if isequal(pn,g)
            target = reward;
        else
            target = reward + gamma*max(Q(sid2,:));
        end
        Q(sid,ai) = Q(sid,ai) + alpha*(target-Q(sid,ai));
        total = total + reward;
        p = pn;
        h = h2;

        if isequal(p,g)
            L.success(ep) = true;
            L.steps(ep) = t;
            break;
        end
    end
    L.reward(ep) = total;
    epsNow = max(emin,epsNow*ed);
end
end

function id = stateID(p,h,nr,nc,headingOn)
if headingOn
    h = max(1,min(8,h));
    id = sub2ind([nr nc 8],p(1),p(2),h);
else
    id = sub2ind([nr nc],p(1),p(2));
end
end

function h = initialHeading(s,g,act)
v = g-s;
[~,h] = min(sum((act-v).^2,2));
end

function th = actionAngle(v)
th = atan2(-v(1),v(2));
end

function x = wrapPi(x)
x = mod(x+pi,2*pi)-pi;
end

function [path,usedFallback] = policyOrBFS(Q,occ,s,g,act,headingOn)
path = extractPath(Q,occ,s,g,act,headingOn,1500);
usedFallback = false;
if ~validRoute(path,s,g,occ)
    path = bfsPath(s,g,occ);
    usedFallback = true;
end
if ~validRoute(path,s,g,occ)
    error('No valid route found by policy or BFS. Check map connectivity.');
end
end

function path = extractPath(Q,occ,s,g,act,headingOn,maxIt)
p = s;
h = initialHeading(s,g,act);
path = p;
seen = false(size(occ,1),size(occ,2),8);
seen(p(1),p(2),h) = true;

for k = 1:maxIt
    sid = stateID(p,h,size(occ,1),size(occ,2),headingOn);
    qv = Q(sid,:);
    [~,ord] = sort(qv,'descend');
    moved = false;
    for z = 1:8
        ai = ord(z);
        pn = p + act(ai,:);
        if pn(1)<1 || pn(1)>size(occ,1) || pn(2)<1 || pn(2)>size(occ,2)
            continue;
        end
        if occ(pn(1),pn(2)), continue; end
        dr = pn(1)-p(1); dc = pn(2)-p(2);
        if dr~=0 && dc~=0 && (occ(p(1)+dr,p(2)) || occ(p(1),p(2)+dc))
            continue;
        end
        if seen(pn(1),pn(2),ai), continue; end
        p = pn;
        h = ai;
        path(end+1,:) = p; %#ok<AGROW>
        seen(p(1),p(2),h) = true;
        moved = true;
        break;
    end
    if isequal(p,g), return; end
    if ~moved, path=[]; return; end
end
path = [];
end

function out = hybridReplan(qPath,occPlan,occOriginal,adaptive,dangerDist,ka,kr,rho0,n,step,maxIt,densityGain)
if isempty(qPath) || size(qPath,1)<2
    out = [];
    return;
end
danger = false(size(qPath,1)-1,1);
for k = 1:numel(danger)
    danger(k) = segmentClearance(qPath(k,:),qPath(k+1,:),occPlan) < dangerDist;
end
out = qPath(1,:);
i = 1;
while i < size(qPath,1)
    if ~danger(i)
        out(end+1,:) = qPath(i+1,:); %#ok<AGROW>
        i = i+1;
        continue;
    end
    j = i;
    while j<numel(danger) && danger(j+1), j=j+1; end
    ib = min(size(qPath,1),j+2);
    local = apfLocal(qPath(i,:),qPath(ib,:),occPlan,occOriginal,ka,kr,rho0,n,step,maxIt,adaptive,densityGain);
    if isempty(local) || ~validRoute(local,qPath(i,:),qPath(ib,:),occPlan)
        local = bfsPath(qPath(i,:),qPath(ib,:),occPlan);
    end
    if isempty(local)
        local = qPath(i:ib,:);
    end
    if isequal(out(end,:),local(1,:)), local=local(2:end,:); end
    if ~isempty(local), out=[out;local]; end %#ok<AGROW>
    i = ib;
end
out = dedup(out);
if ~isPathSafe(out,occPlan)
    out = bfsPath(qPath(1,:),qPath(end,:),occPlan);
end
end

function path = apfLocal(s,g,occ,occOriginal,ka,kr,rho0,n,step,maxIt,adaptive,densityGain)
[or,oc] = find(occ);
obs = [or oc];
[orr,orc] = find(occOriginal);
obsOriginal = [orr orc];
q = double(s);
g = double(g);
path = q;
oldD = inf;
stuck = 0;

for it = 1:maxIt
    dg = norm(q-g);
    if dg < 0.35
        path = [path;g]; %#ok<AGROW>
        path = round(path);
        path = dedup(path);
        return;
    end
    Fatt = -ka*(q-g);
    Frep = [0 0];
    dif = q-obs;
    ds = sqrt(sum(dif.^2,2));
    ids = find(ds<=rho0 & ds>1e-8);

    eta = kr;
    if adaptive
        rad = 2.5;
        d0 = sqrt(sum((obsOriginal-q).^2,2));
        localDensity = sum(d0<=rad)/((2*rad+1)^2);
        eta = kr*(1+densityGain*min(1,localDensity));
    end
    ng = (g-q)/(dg+eps);
    for z = 1:numel(ids)
        j = ids(z);
        rho = max(ds(j),0.15);
        nh = dif(j,:)/rho;
        zeta = max(0,1/rho-1/rho0);
        f1 = eta*zeta/(rho^2)*(dg^n)*nh;
        f2 = -(n/2)*eta*zeta^2*(dg^(n-1))*ng;
        Frep = Frep + f1 + f2;
    end
    F = Fatt + Frep;
    nf = norm(F);
    if nf < 1e-10, path=[]; return; end
    vec = step*F/nf;
    accepted = false;
    for sh = 0:8
        cand = q + vec/(2^sh);
        if segmentSafe(q,cand,occ)
            accepted = true;
            break;
        end
    end
    if ~accepted, path=[]; return; end
    newD = norm(cand-g);
    if newD >= oldD-1e-4, stuck=stuck+1; else, stuck=max(0,stuck-1); end
    if stuck>50, path=[]; return; end
    oldD = newD;
    q = cand;
    path(end+1,:) = q; %#ok<AGROW>
end
path = [];
end

function occ2 = inflateObstacles(occ,radius)
[nr,nc] = size(occ);
occ2 = occ;
reach = ceil(radius);
[rr,cc] = find(occ);
for k = 1:numel(rr)
    for dr = -reach:reach
        for dc = -reach:reach
            if hypot(dr,dc) <= radius+1e-9
                r = rr(k)+dr;
                c = cc(k)+dc;
                if r>=1 && r<=nr && c>=1 && c<=nc
                    occ2(r,c) = true;
                end
            end
        end
    end
end
end

function path = bfsPath(s,g,occ)
[nr,nc] = size(occ);
moves = [-1 0;1 0;0 -1;0 1;-1 -1;-1 1;1 -1;1 1];
if occ(s(1),s(2)) || occ(g(1),g(2)), path=[]; return; end
visited = false(nr,nc);
parentR = zeros(nr,nc);
parentC = zeros(nr,nc);
queue = zeros(nr*nc,2);
head = 1; tail = 1;
queue(1,:) = s;
visited(s(1),s(2)) = true;

while head<=tail
    p = queue(head,:);
    head = head+1;
    if isequal(p,g), break; end
    for a = 1:8
        pn = p+moves(a,:);
        r = pn(1); c = pn(2);
        if r<1 || r>nr || c<1 || c>nc || occ(r,c) || visited(r,c)
            continue;
        end
        dr = r-p(1); dc = c-p(2);
        if dr~=0 && dc~=0 && (occ(p(1)+dr,p(2)) || occ(p(1),p(2)+dc))
            continue;
        end
        visited(r,c) = true;
        parentR(r,c) = p(1);
        parentC(r,c) = p(2);
        tail = tail+1;
        queue(tail,:) = pn;
    end
end

if ~visited(g(1),g(2)), path=[]; return; end
path = g;
p = g;
while ~isequal(p,s)
    pr = parentR(p(1),p(2));
    pc = parentC(p(1),p(2));
    if pr==0 && pc==0, path=[]; return; end
    p = [pr pc];
    path = [p;path]; %#ok<AGROW>
end
end

function d = segmentClearance(a,b,occ)
[r,c] = find(occ);
if isempty(r), d=inf; return; end
ob = [r c];
ns = max(2,ceil(norm(b-a)*10));
d = inf;
for k = 0:ns
    p = a+(b-a)*k/ns;
    dd = sqrt(sum((ob-p).^2,2));
    d = min(d,min(dd));
end
end

function tf = segmentSafe(a,b,occ)
ns = max(2,ceil(norm(b-a)*20));
tf = true;
for k = 0:ns
    p = round(a+(b-a)*k/ns);
    if p(1)<1 || p(1)>size(occ,1) || p(2)<1 || p(2)>size(occ,2) || occ(p(1),p(2))
        tf=false; return;
    end
end
end

function tf = isPathSafe(p,occ)
tf = ~isempty(p);
if ~tf, return; end
for k = 1:size(p,1)
    r=round(p(k,1)); c=round(p(k,2));
    if r<1 || r>size(occ,1) || c<1 || c>size(occ,2) || occ(r,c)
        tf=false; return;
    end
end
for k = 1:size(p,1)-1
    if ~segmentSafe(p(k,:),p(k+1,:),occ), tf=false; return; end
end
end

function tf = validRoute(p,s,g,occ)
tf = isPathSafe(p,occ) && size(p,1)>=2 && isequal(round(p(1,:)),s) && isequal(round(p(end,:)),g);
end

function p = safeSmooth(p,occ,w)
if size(p,1)<=2 || w<=0, return; end
candidate = p;
for k=2:size(p,1)-1
    lo=max(1,k-w); hi=min(size(p,1),k+w);
    candidate(k,:)=mean(p(lo:hi,:),1);
end
candidate(1,:)=p(1,:); candidate(end,:)=p(end,:);
if isPathSafe(candidate,occ), p=candidate; end
end

function p = dedup(p)
if isempty(p), return; end
p=p([true;any(diff(p,1,1)~=0,2)],:);
end

function y = smoothCurve(x,w)
x=x(:);
n=numel(x);
y=zeros(n,1);
w=max(3,round(w));
if mod(w,2)==0, w=w+1; end
h=(w-1)/2;
weights=[1:h+1 h:-1:1]';
for k=1:n
    lo=max(1,k-h); hi=min(n,k+h);
    idx=lo-(k-h)+1:hi-(k-h)+1;
    ww=weights(idx);
    y(k)=sum(x(lo:hi).*ww/sum(ww));
end
end


function p2 = lineOfSightShortcut(p,occ)
% Greedy string-pulling. From each retained node, connect to the farthest
% later node whose full segment is collision-free in the inflated occupancy map.
if size(p,1)<=2, p2=p; return; end
p2=p(1,:);
i=1;
while i<size(p,1)
    chosen=i+1;
    for j=size(p,1):-1:(i+1)
        if segmentSafe(p(i,:),p(j,:),occ)
            chosen=j;
            break;
        end
    end
    p2(end+1,:)=p(chosen,:); %#ok<AGROW>
    i=chosen;
end
p2=dedup(p2);
end

function a = totalTurningAngle(p)
a=0;
for k=2:size(p,1)-1
    v1=p(k,:)-p(k-1,:);
    v2=p(k+1,:)-p(k,:);
    if norm(v1)>0 && norm(v2)>0
        a=a+abs(wrapPi(atan2(-v2(1),v2(2))-atan2(-v1(1),v1(2))));
    end
end
a=a*180/pi;
end

function a = maximumTurningAngle(p)
a=0;
for k=2:size(p,1)-1
    v1=p(k,:)-p(k-1,:);
    v2=p(k+1,:)-p(k,:);
    if norm(v1)>0 && norm(v2)>0
        da=abs(wrapPi(atan2(-v2(1),v2(2))-atan2(-v1(1),v1(2))));
        a=max(a,da);
    end
end
a=a*180/pi;
end

function L = pathLength(p)
if size(p,1)<2, L=0; else, L=sum(sqrt(sum(diff(p,1,1).^2,2))); end
end

function n = turnCount(p)
n=0;
for k=2:size(p,1)-1
    v1=p(k,:)-p(k-1,:);
    v2=p(k+1,:)-p(k,:);
    if norm(v1)>0 && norm(v2)>0
        da=abs(wrapPi(atan2(-v2(1),v2(2))-atan2(-v1(1),v1(2))));
        if da>1e-3, n=n+1; end
    end
end
end

function d = minClearance(p,occ)
if size(p,1)<2, d=NaN; return; end
d=inf;
for k=1:size(p,1)-1
    d=min(d,segmentClearance(p(k,:),p(k+1,:),occ));
end
end

function drawMap(occ,occPlan)
imagesc(~occ);
set(gca,'YDir','normal');
axis equal tight;
colormap([0.2 0.2 0.2;1 1 1]);
hold on;
[r,c]=find(occPlan & ~occ);
plot(c,r,'s','Color',[0.55 0.55 0.55],'MarkerSize',5);
set(gca,'XTick',1:2:size(occ,2),'YTick',1:2:size(occ,1));
grid on;
xlim([0.5 size(occ,2)+0.5]);
ylim([0.5 size(occ,1)+0.5]);
xlabel('Grid column coordinate'); ylabel('Grid row coordinate');
title('Black: obstacles; gray markers: inflated safety region');
end
