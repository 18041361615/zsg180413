"""从随包仿真CSV生成单文件离线回放台；不产生新的仿真结果。"""
from pathlib import Path
import json, csv, argparse

ROOT=Path(__file__).resolve().parent
SCENARIOS={
 'normal':('正常传感器 / 环境扰动','两路传感器正常；室外温度在90 min与150 min下降。观察三种策略保持相同控制响应。'),
 'bias':('主传感器 +3°C 偏置','120 min起主传感器出现+3°C偏置。观察测量与温度真值的分离，以及故障诊断后反馈通道的切换。'),
 'stuck':('主传感器卡死','120 min起主传感器保持故障发生时的读数。参考传感器继续采样，规则与AI诊断根据窗口特征选择反馈。'),
 'noise':('主传感器噪声增强','120 min起主传感器附加标准差0.8°C噪声。比较控制输入波动与诊断切换后的温度表现。'),
 'parameter_shift':('对象参数变化 / 能力不足','120 min起供热增益下降15%、时间常数增大30%。最终最大可达温度仅19°C，22°C目标不可达，诊断不能补足供热能力。')
}
CONTROLLERS={'plain_pi':'普通PI','rule_pi':'规则诊断 + PI','ai_pi':'MindSpore诊断 + PI（含规则守护）'}

def make_payload(project):
 s=json.loads((project/'results/result_summary.json').read_text(encoding='utf-8'))
 lookup={(m['scenario'],m['controller']):m for m in s['closed_loop']}
 episodes=[]
 for scenario in SCENARIOS:
  for controller in CONTROLLERS:
   file=project/'results'/f'{scenario}__{controller}.csv'
   rows=[]
   with file.open(encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f):
     rows.append({k:round(float(r[col]),6) for k,col in {
      't':'t_s','temp':'T_true_degC','setpoint':'Tset_degC','y1':'primary_degC',
      'y2':'reference_degC','u':'control_pu','diagnosis':'predicted_label',
      'reference':'reference_selected','confidence':'prediction_confidence'}.items()})
   m=lookup[scenario,controller]
   metric={'rmse':m['rmse_degC'],'max_error':m['maximum_absolute_error_degC'],
    'outside_minutes':m['outside_comfort_min'],'input_minutes':m['input_integral_pu_h']*60,
    'iae_minutes':m['iae_degC_h']*60,'variation_u':m['total_variation_u']}
   episodes.append({'scenario':scenario,'controller':controller,'rows':rows,'metrics':metric,'source':f'results/{file.name}'})
 return {'scenarios':[{'key':k,'label':v[0],'description':v[1]} for k,v in SCENARIOS.items()],
  'controllers':[{'key':k,'label':v} for k,v in CONTROLLERS.items()], 'episodes':episodes,
  'class_names':s['classification']['labels'],'threshold_note':'舒适带 [20, 24] °C',
  'metric_note':'表中指标统一按120–240 min评估；RMSE、IAE和最大偏差基于仿真真值。阈值外时长指温度不在[20,24]°C内。输入积分仅为归一化执行量代理，不代表实测kWh、费用或碳排；单次固定种子，不表明AI普遍优于规则。',
  'provenance':{'summary':'results/result_summary.json','seed':s['config']['seed'],'framework':s['classification']['framework'],'checkpoint_sha256':s['checkpoint_sha256']}}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=ROOT.parent/'sim_project');a=p.parse_args()
 data=make_payload(a.project)
 html=(ROOT/'replay_template.html').read_text(encoding='utf-8').replace('__PAYLOAD__',json.dumps(data,ensure_ascii=False,separators=(',',':')))
 html=html.replace('全仿真区间','120–240 min评估区间')
 html=html.replace("['正常','偏置','卡死','噪声','参考反馈']","current.controller==='rule_pi'?['正常','规则报警','','','参考反馈']:['正常','偏置','卡死','噪声','参考反馈']")
 out=ROOT/'寒地智慧供热-离线仿真回放.html';out.write_text(html,encoding='utf-8')
 print(out);print('episodes=',len(data['episodes']),'bytes=',out.stat().st_size)
