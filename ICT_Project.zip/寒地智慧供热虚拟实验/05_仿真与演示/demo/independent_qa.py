"""独立复核仿真CSV、集合隔离与已保存checkpoint推理的一致性。"""
from pathlib import Path
import json, csv, sys, argparse
import numpy as np
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--project',type=Path,default=ROOT.parent/'sim_project')
PROJECT=parser.parse_args().project.resolve()
sys.path.insert(0,str(PROJECT/'src'))
from core import Predictor, FEATURES, classification_stats

def read_csv(path):
 with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

summary=json.loads((PROJECT/'results/result_summary.json').read_text())
dt=summary['config']['Ts_s'];checks=[]
for m in summary['closed_loop']:
 rows=read_csv(PROJECT/'results'/f"{m['scenario']}__{m['controller']}.csv")
 post=[r for r in rows if float(r['t_s'])>=m['evaluation_start_s']]
 e=np.array([float(r['Tset_degC'])-float(r['T_true_degC']) for r in post])
 u=np.array([float(r['control_pu']) for r in post]);T=np.array([float(r['T_true_degC']) for r in post])
 calc={'rmse_degC':float(np.sqrt(np.mean(e**2))),
  'iae_degC_h':float(np.sum(np.abs(e))*dt/3600),
  'maximum_absolute_error_degC':float(np.max(np.abs(e))),
  'outside_comfort_min':float(np.sum((T<20)|(T>24))*dt/60),
  'input_integral_pu_h':float(np.sum(u)*dt/3600),'total_variation_u':float(np.sum(np.abs(np.diff(u))))}
 error={k:abs(v-m[k]) for k,v in calc.items()}
 checks.append({'scenario':m['scenario'],'controller':m['controller'],'max_absolute_metric_difference':max(error.values()),'all_input_within_0_1':bool(np.all((u>=0)&(u<=1)))})

sets={s:read_csv(PROJECT/'data'/f'{s}.csv') for s in ['train','val','test']}
episodes={k:set(r['episode'] for r in v) for k,v in sets.items()}
seeds={k:set(r['episode_seed'] for r in v) for k,v in sets.items()}
disjoint=all(not(episodes[a]&episodes[b]) and not(seeds[a]&seeds[b]) for a,b in [('train','val'),('train','test'),('val','test')])
X=np.array([[float(r[f]) for f in FEATURES] for r in sets['train']],np.float32)
scaler=np.load(PROJECT/'models/scaler.npz')
scaler_match=bool(np.allclose(scaler['mean'],X.mean(0)) and np.allclose(scaler['scale'],np.maximum(X.std(0),1e-6)))
predictor=Predictor(PROJECT)
pred=np.array([predictor.predict(np.array([float(r[f]) for f in FEATURES],np.float32))[0] for r in sets['test']])
y=np.array([int(r['label']) for r in sets['test']])
stats=classification_stats(y,pred)
result={'csv_metric_recalculation':checks,'independent_episodes_and_seeds_across_splits':disjoint,
 'scaler_fitted_only_on_train_and_matches_checkpoint_scaler':scaler_match,
 'saved_checkpoint_reloaded_test_classification':stats,
 'classification_matches_summary':bool(np.isclose(stats['macro_f1'],summary['classification']['macro_f1'])),
 'feature_source_review':'extract_features仅使用两路传感器窗口；T_true/fault_active/label没有传入Predictor。',
 'limitations_review':'AI通道含规则守护，不能归因AI单独贡献。参考传感器始终健康，缺少共因失效。仅固定种子主基线，未作普遍优越性推断。'}
(ROOT/'independent_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
assert disjoint and scaler_match and result['classification_matches_summary']
assert all(c['max_absolute_metric_difference']<1e-10 and c['all_input_within_0_1'] for c in checks)
print('Independent verification passed: 15 CSVs, split disjointness, scaler, 2400-window checkpoint inference.')
