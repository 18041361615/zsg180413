#!/usr/bin/env python3
"""只在127.0.0.1提供现场结果复核面板；按钮真实执行项目verify_results.py。"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import argparse, json, os, subprocess, sys, datetime, hashlib
from zoneinfo import ZoneInfo

P=argparse.ArgumentParser();P.add_argument('--project',type=Path,default=Path(__file__).resolve().parent.parent/'sim_project');P.add_argument('--port',type=int,default=39137);P.add_argument('--dependencies',type=Path)
args=P.parse_args();project=args.project.resolve();template=Path(__file__).with_name('live_verification_panel.html')
class Handler(BaseHTTPRequestHandler):
 def send_json(self,obj,status=200):
  data=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if self.path=='/':
   data=template.read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  elif self.path=='/metadata':
   self.send_json({'project':str(project),'command':sys.executable+' verify_results.py','environment':('PYTHONPATH='+str(args.dependencies.resolve())) if args.dependencies else '使用当前Python环境', 'verification_sha256':hashlib.sha256((project/'verify_results.py').read_bytes()).hexdigest(),'original_log_name':'results/run_all_original.log','original_log':(project/'results/run_all_original.log').read_text(encoding='utf-8')})
  else:self.send_error(404)
 def do_POST(self):
  if self.path!='/verify':self.send_error(404);return
  env=os.environ.copy()
  if args.dependencies:env['PYTHONPATH']=str(args.dependencies.resolve())
  started=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds')
  proc=subprocess.run([sys.executable,'verify_results.py'],cwd=project,env=env,text=True,capture_output=True,timeout=60)
  ended=datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds')
  self.send_json({'started_beijing':started,'ended_beijing':ended,'exit_code':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr,'executed_script':'verify_results.py','read_only_verification':True})
 def log_message(self,*a):pass
print(f'Live read-only verification panel: http://127.0.0.1:{args.port}',flush=True)
ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
