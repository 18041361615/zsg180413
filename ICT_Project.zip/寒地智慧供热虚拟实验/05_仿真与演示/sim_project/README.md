# 寒地智慧供热：昇思MindSpore诊断与安全温控仿真实验

本目录是**已经实际运行的纯软件教学作品**，不是实体供热系统。数据均为程序合成；MindSpore 2.7.2 在 Linux x86_64 CPU 上完成真实训练、checkpoint保存、预测及闭环运行。未连接华为云、没有硬件在环，没有真实课堂、真实节能率或学生学习增益证据。

## 1. 交付内容与先看哪里

- `run_experiments.py`：统一入口；`config.json`：全部可调整参数。
- `src/core.py`：数据生成、8维可观测特征、MindSpore MLP、PI、参考传感器选择、评分与图表。
- `models/diagnostic.ckpt`：实际训练checkpoint；`models/scaler.npz`：仅训练集拟合的均值/标准差；`training_config.json`：训练配置记录。
- `data/train.csv`、`val.csv`、`test.csv`：窗口特征，附独立episode ID和seed；对应`*_episodes.npz`保留原始双传感器序列。
- `data/challenge_weak.csv`：训练分布外的弱故障挑战，未用于调参。
- `results/result_summary.json`：机器可读结果与局限；`closed_loop_metrics.csv`：15组完整指标；`{scenario}__{controller}.csv`：每组1440行采样轨迹。
- `results/test_predictions.csv`、`challenge_weak_predictions.csv`：逐窗预测；`training_history.csv`：70轮实际损失。
- `results/run_all_original.log`：实际首次完整运行日志，保留原始输出；`run_challenge_original.log`为追加弱故障评估日志。
- `figures/*.jpg`：200 dpi图表；`verify_results.py`：不依赖MindSpore的指标和数据划分复核。

## 2. 隔离环境复现

已验证环境为 Python 3.12.14、MindSpore 2.7.2、NumPy 1.26.4、Matplotlib 3.10.8、pandas 2.2.3，Linux x86_64 CPU。建议Python 3.12；其他平台先确认MindSpore官方CPU wheel支持。依赖不会打包进作品，首次安装需联网，MindSpore wheel约775 MB。本作品无华为云账号、API密钥或收费服务要求。

Linux/macOS终端（macOS运行支持取决于MindSpore发行包，未在本次验证）：

```bash
cd sim_project
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MPLCONFIGDIR="$PWD/.matplotlib_cache"
python run_experiments.py --all
python verify_results.py
```

Windows PowerShell（该平台未在本次执行验证）：

```powershell
cd sim_project
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:OMP_NUM_THREADS="1"
$env:OPENBLAS_NUM_THREADS="1"
$env:MPLCONFIGDIR="$PWD\.matplotlib_cache"
python run_experiments.py --all
python verify_results.py
```

实际制作时为避免修改系统Python，使用`python -m pip install --target /workspace/work/ms_deps mindspore==2.7.2`隔离依赖，并以`PYTHONPATH=/workspace/work/ms_deps OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python run_experiments.py --all`运行；交付不包含这个临时安装目录。上述venv命令用于接收者自己的环境。

单步命令：

```bash
python run_experiments.py --train      # 重新生成划分，训练、验证选轮次、测试；不重算闭环
python run_experiments.py --simulate   # 读取现有checkpoint，重新跑5工况×3基线
python run_experiments.py --challenge  # 读取现有checkpoint，仅做固定分布外弱故障评估
python run_experiments.py --figures    # 从已保存CSV/JSON重绘；不重新训练
python run_experiments.py --all --config config_student.json
```

先复制原工程，再修改`config_student.json`。修改窗口长度、采样周期、训练噪声或数据生成逻辑时必须`--all`重新训练评估。只改PI参数/故障幅值/舒适带可`--simulate`重算闭环，但图表需再执行`--figures`。`--train`以后旧闭环CSV不是新模型结果，必须再`--simulate`；`--all`是最可靠的一次性复现方法。修改仿真参数不代表模型已对新分布有效。

图中文字需系统安装中文字体。脚本依次尝试Noto Sans CJK、微软雅黑、苹方，找不到时系统默认字体可能显示方框，但不影响数值结果。

## 3. 对象、传感器与控制

单区域教学模型：

`dT/dt=-(T-Tout)/tau+(K/tau)u`，`0≤u≤1`。

使用解析离散化：`a=exp(-Ts/tau)`，`T[k+1]=a*T[k]+(1-a)*(Tout[k]+K*u[k])`。

标称`K=40℃/p.u., tau=1800s, Ts=10s`；目标22℃。双虚拟温度传感器独立高斯测量噪声`σ=0.03℃`。在本基准中**参考传感器始终健康**；两路只是教学冗余，不宣称真实设备已有双冗余。

PI参数`Kp=0.075 p.u./℃`、`Ki=1/24000 p.u./(℃·s)`，可由`Kp=tau/(K*lambda), Ki=1/(K*lambda), lambda=600s`给出初值。初始积分量为平衡热输入0.8，输出限幅0～1并采用条件积分抗饱和。对象真温度只用于仿真更新与评分；控制量只根据被选中的传感器观测计算。

滚动20点窗口名义覆盖200s采样长度。8维特征依次为：双观测残差均值、残差标准差、主传感器平均绝对差分、参考传感器平均绝对差分、主观测标准差、参考观测标准差、残差差分标准差、残差绝对值均值。**全部可从y1/y2得到，不包含真温度、故障标签、未来值。**

## 4. MindSpore训练、划分及挑战

MLP结构8→24→16→4，隐藏层ReLU，共684个可训练参数；Adam学习率0.003、batch256、70轮；交叉熵最小的验证轮次checkpoint用于最终测试。种子20261115；分割seed偏移分别0、1,000,000、2,000,000，挑战为4,000,000。每episode生成400点，20点不重叠取窗：

| 集合 | 独立episode | 窗口 | 每类窗口 |
|---|---:|---:|---:|
| 训练 | 320 | 6400 | 1600 |
| 验证 | 80 | 1600 | 400 |
| 测试 | 120 | 2400 | 600 |

先按独立episode和seed划分，再取窗口；同一episode不会跨集合。标准化仅用训练集；验证集选轮次，测试集不调模型。合成对象的`K∈[34,46]`、`tau∈[1400,2400]`、`Tout∈[-18,-6]`，随机分段热输入。四类为正常、偏置（±1～4℃）、卡死（极小0.001℃抖动）、噪声（额外σ0.3～1℃）。

清晰合成故障独立测试准确率/宏F1均1.000；这是容易区分的同族合成分布，不是工程性能承诺。同一episode内的20个窗口相关，不能当2400个独立实物实验。

固定模型的弱故障挑战另生成80个episode/1600窗：偏置仅±0.1～0.3℃、附加噪声σ0.05～0.15℃，其余设置相同，准确率51.44%、宏F1=0.4040；400个弱偏置窗全部被判正常，400个弱噪声窗仅23个判噪声。挑战没有反向用于重训、选阈值或改规则。该反例用于教授可检出性、分布迁移与证据边界。

## 5. 三种方案与防护

- `plain_pi`：普通PI，始终使用主传感器。
- `rule_pi`：预先固定的简单规则诊断+PI：残差均值绝对值>0.8℃；或主差分均值>0.30℃；或主差分<0.003℃且参考差分>0.015℃时判异常。
- `ai_pi`：MindSpore非正常类别且置信度≥0.70时判异常；额外独立残差守护`|mean(y1-y2)|>1.5℃`。**AI方案含规则守护，不能将整体收益归因于神经网络单独作用。**

连续3个采样异常后选健康参考传感器，连续10个采样正常后恢复主传感器。该滞回是教学保护逻辑，不是工业安全认证。低置信、参考故障、共同失效都需要扩展独立安全论证，本作品不声称覆盖。

闭环故障刚发生时，滚动窗同时含故障前后样本，其特征可能以其他非正常类别触发切换；**`first_reference_delay_s`只是第一次选参考传感器的延迟，不是故障类别正确确诊时延**。偏置工况20s切换并不表示20点完整故障窗已到齐，也不代表200s的等待时间。

## 6. 五工况与真实数值

所有闭环4h（1440步）；t=7200s故障/参数改变；外温初始−10℃，t=5400s变−13℃，t=9000s变−15℃。比较在同一工况的三控制器使用完全相同的噪声序列。指标统计后2h；仿真真值只评分，不送入控制/诊断。

| 工况 | 普通PI RMSE℃ | 规则+PI | AI+PI |
|---|---:|---:|---:|
| 正常 | 0.3151 | 0.3151 | 0.3151 |
| 主传感器偏置+3℃ | 3.0787 | 0.3563 | 0.3266 |
| 主传感器卡死 | 1.1643 | 0.3129 | 0.3131 |
| 主传感器额外噪声σ0.8℃ | 0.4121 | 0.3219 | 0.3191 |
| K降15%、tau增30% | 2.1411 | 2.1411 | 2.1411 |

偏置工况普通PI在20～24℃舒适带外112.33min，两种诊断方案均0min。AI没有在全部工况上优于规则：卡死工况略逊规则；两种诊断的多数收益来自健康参考替代受故障主传感器。

参数变化工况K=34且最终Tout=−15℃，即使u=1最大稳态室温只有19℃，目标22℃物理不可达。三者均有69min在舒适带外，不能通过诊断解决热源能力不足。不要把这个工况包装成已解决问题。

定义：RMSE为温度误差均方根；IAE为`Σ|误差|Ts/3600`（℃·h）；舒适带外时长为`Ttrue∉[20,24]`采样时长；输入积分为`ΣuTs/3600`（p.u.·h）；执行变化量为`Σ|Δu|`。输入积分只是归一化执行量代理，无法换算实际kWh、费用、节能率或碳排。偏置普通PI输入积分更低但室温不合格，不能称节能更优。

## 7. 课堂操作建议与边界

先不启用AI，计算对象平衡点与PI整定，再注入主传感器故障，比较双传感器规则基线与MLP方案；最后运行弱故障挑战及参数能力不足反例。学生应提交配置、代码版本、完整CSV、结论与反例，不只交一张好看的曲线。具体课时、教案、评价量规以配套教学手册为准。

本次只证明这套代码可在CPU上复现既定合成实验，没有真实传感器标定、微控制器烧录、设备通信时延、硬件执行周期、真实建筑辨识、真实课堂对照/成绩与真实能耗数据。模型训练中的满分不能外推至实体或微小故障；当前没有多随机种子重复和置信区间，不能宣称普遍优于规则。图表和结果必须与上述证据边界一起呈现。
