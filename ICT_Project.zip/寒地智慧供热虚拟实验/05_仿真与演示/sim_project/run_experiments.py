#!/usr/bin/env python3
"""python run_experiments.py --all | --train | --simulate | --figures"""
from pathlib import Path
import argparse, json
from src.core import train, simulate, write_summary, make_figures, challenge

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='寒地智慧供热纯软件实验；配置见config.json')
    ap.add_argument('--all',action='store_true');ap.add_argument('--train',action='store_true')
    ap.add_argument('--simulate',action='store_true');ap.add_argument('--figures',action='store_true')
    ap.add_argument('--challenge',action='store_true')
    ap.add_argument('--config',default='config.json');args=ap.parse_args()
    root=Path(__file__).resolve().parent
    cfg=json.loads((root/args.config).read_text(encoding='utf-8'))
    for d in ['data','models','results','figures']:(root/d).mkdir(exist_ok=True)
    if not any([args.all,args.train,args.simulate,args.figures,args.challenge]):ap.error('请选择--all/--train/--simulate/--figures')
    if args.all or args.train:cl=train(cfg,root)
    else:cl=json.loads((root/'results/classification.json').read_text(encoding='utf-8'))
    if args.all or args.simulate:metrics=simulate(cfg,root)
    else:
        old=root/'results/result_summary.json'
        metrics=json.loads(old.read_text(encoding='utf-8'))['closed_loop'] if old.exists() else []
    if args.all or args.challenge:challenge(cfg,root)
    s=write_summary(cfg,root,cl,metrics)
    if args.all or args.figures:make_figures(root,s)
    print('完成。结果：results/result_summary.json；图表：figures/*.jpg')
