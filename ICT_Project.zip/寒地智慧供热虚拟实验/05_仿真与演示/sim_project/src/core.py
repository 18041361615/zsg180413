"""可复现的合成传感器诊断与离散PI闭环；所有真值仅用于仿真及评分。"""
from pathlib import Path
import csv, json, platform, hashlib
import numpy as np

LABELS = ['正常', '偏置', '卡死', '噪声']
FEATURES = ['residual_mean', 'residual_std', 'primary_delta_abs_mean',
            'reference_delta_abs_mean', 'primary_std', 'reference_std',
            'residual_delta_std', 'residual_abs_mean']
SCENARIOS = ['normal', 'bias', 'stuck', 'noise', 'parameter_shift']
SCENARIO_ZH = dict(zip(SCENARIOS, ['正常', '偏置+3℃', '主传感器卡死', '主传感器噪声', '对象参数变化']))
CONTROLLERS = ['plain_pi', 'rule_pi', 'ai_pi']
CONTROLLER_ZH = dict(zip(CONTROLLERS, ['普通PI', '规则诊断+PI', 'MindSpore诊断+PI']))


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def extract_features(y1, y2):
    """8维量全部可由双传感器采样计算，不读取对象真温度/故障标签。"""
    y1, y2 = np.asarray(y1), np.asarray(y2)
    r = y1-y2
    return np.array([r.mean(), r.std(), np.abs(np.diff(y1)).mean(),
                     np.abs(np.diff(y2)).mean(), y1.std(), y2.std(),
                     np.diff(r).std(), np.abs(r).mean()], dtype=np.float32)


def generate_split(cfg, name, n_episodes, seed_offset, root, weak=False):
    """每个episode独立seed，划分后才取窗，杜绝重叠窗跨集合。"""
    rows, raw_primary, raw_reference, raw_labels, episode_ids = [], [], [], [], []
    n, w = cfg['episode_samples'], cfg['window_samples']
    for label in range(4):
        for ep in range(n_episodes):
            seed = cfg['seed'] + seed_offset + label*10000 + ep
            rng = np.random.default_rng(seed)
            K = rng.uniform(34, 46); tau = rng.uniform(1400, 2400)
            a = np.exp(-cfg['Ts_s']/tau)
            tout = rng.uniform(-18, -6); T = rng.uniform(18, 26)
            true = np.zeros(n)
            u = rng.uniform(.3, 1.0)
            for k in range(n):
                if k % 40 == 0: u = rng.uniform(.3, 1.0)
                T = a*T + (1-a)*(tout+K*u)
                true[k] = T
            y2 = true+rng.normal(0, cfg['sensor_sigma_degC'], n)
            y1 = true+rng.normal(0, cfg['sensor_sigma_degC'], n)
            if label == 1:
                y1 += rng.choice([-1, 1])*rng.uniform(.1, .3) if weak else rng.choice([-1, 1])*rng.uniform(1, 4)
            elif label == 2:
                y1 = np.full(n, true[0])+rng.normal(0, .001, n)
            elif label == 3:
                y1 += rng.normal(0, rng.uniform(.05, .15) if weak else rng.uniform(.3, 1.0), n)
            eid = f'{name}_{label}_{ep:03d}'
            for end in range(w, n+1, w):
                feat = extract_features(y1[end-w:end], y2[end-w:end])
                row = {'split':name, 'episode':eid, 'episode_seed':seed,
                       'end_sample':end, 'label':label}
                row.update(dict(zip(FEATURES, map(float,feat))))
                rows.append(row)
            raw_primary.append(y1); raw_reference.append(y2)
            raw_labels.append(label); episode_ids.append(eid)
    write_csv(root/'data'/f'{name}.csv', rows)
    np.savez_compressed(root/'data'/f'{name}_episodes.npz',
                        primary=np.array(raw_primary), reference=np.array(raw_reference),
                        label=np.array(raw_labels), episode=np.array(episode_ids))
    X = np.array([[r[k] for k in FEATURES] for r in rows], np.float32)
    y = np.array([r['label'] for r in rows], np.int32)
    return X, y, rows


def build_network():
    from mindspore import nn
    return nn.SequentialCell(nn.Dense(8,24), nn.ReLU(),
                             nn.Dense(24,16), nn.ReLU(), nn.Dense(16,4))


def classification_stats(y, pred):
    cm = np.zeros((4,4),int)
    for a,b in zip(y,pred): cm[a,b]+=1
    f1 = []
    for k in range(4):
        tp=cm[k,k]; den=cm[k,:].sum()+cm[:,k].sum()
        f1.append(float(2*tp/den) if den else 0.0)
    return {'accuracy':float(np.mean(y==pred)), 'macro_f1':float(np.mean(f1)),
            'class_f1':f1, 'confusion_matrix':cm.tolist()}


def softmax(x):
    ex=np.exp(x-x.max(axis=-1,keepdims=True))
    return ex/ex.sum(axis=-1,keepdims=True)


def train(cfg, root):
    import mindspore as ms
    from mindspore import nn, Tensor, ops
    ms.set_context(mode=ms.PYNATIVE_MODE)
    ms.set_device('CPU'); ms.set_seed(cfg['seed'])
    X,y,_=generate_split(cfg,'train',cfg['train_episodes_per_class'],0,root)
    V,vy,_=generate_split(cfg,'val',cfg['val_episodes_per_class'],1000000,root)
    Z,zy,zrows=generate_split(cfg,'test',cfg['test_episodes_per_class'],2000000,root)
    mean=X.mean(0); scale=np.maximum(X.std(0),1e-6)
    np.savez(root/'models/scaler.npz',mean=mean,scale=scale)
    (root/'models/training_config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    X=(X-mean)/scale; V=(V-mean)/scale; Z=(Z-mean)/scale
    net=build_network()
    loss_fn=nn.SoftmaxCrossEntropyWithLogits(sparse=True,reduction='mean')
    opt=nn.Adam(net.trainable_params(),learning_rate=cfg['learning_rate'])
    def forward(xx,yy): return loss_fn(net(xx),yy)
    grad_fn=ms.value_and_grad(forward,None,opt.parameters)
    def step(xx,yy):
        loss,grads=grad_fn(xx,yy); opt(grads); return float(loss.asnumpy())
    rng=np.random.default_rng(cfg['seed']+99); logs=[]; best_loss=float('inf')
    for epoch in range(cfg['epochs']):
        net.set_train(True); perm=rng.permutation(len(X)); losses=[]
        for start in range(0,len(X),cfg['batch_size']):
            idx=perm[start:start+cfg['batch_size']]
            losses.append(step(Tensor(X[idx],ms.float32),Tensor(y[idx],ms.int32)))
        net.set_train(False)
        vlogits=net(Tensor(V,ms.float32))
        vloss=float(loss_fn(vlogits,Tensor(vy,ms.int32)).asnumpy())
        vacc=float((vlogits.asnumpy().argmax(1)==vy).mean())
        logs.append(dict(epoch=epoch+1,train_loss=float(np.mean(losses)),val_loss=vloss,val_accuracy=vacc))
        if vloss < best_loss:
            best_loss=vloss; ms.save_checkpoint(net,str(root/'models/diagnostic.ckpt')); best_epoch=epoch+1
        if (epoch+1)%10==0: print(f'epoch={epoch+1},val_loss={vloss:.5f},accuracy={vacc:.4f}',flush=True)
    ms.load_param_into_net(net,ms.load_checkpoint(str(root/'models/diagnostic.ckpt')))
    net.set_train(False)
    logits=net(Tensor(Z,ms.float32)).asnumpy(); probs=softmax(logits); pred=probs.argmax(1)
    stats=classification_stats(zy,pred)
    stats.update({'test_windows':len(Z),'train_windows':len(X),'val_windows':len(V),
                  'train_episodes':cfg['train_episodes_per_class']*4,
                  'val_episodes':cfg['val_episodes_per_class']*4,
                  'test_episodes':cfg['test_episodes_per_class']*4,
                  'best_epoch':best_epoch,'seed':cfg['seed'],'window_samples':cfg['window_samples'],
                  'window_duration_s':cfg['window_samples']*cfg['Ts_s'],
                  'framework':f'MindSpore {ms.__version__} CPU',
                  'labels':LABELS,'features':FEATURES,
                  'split_policy':'按独立episode和独立seed先划分；同一episode的窗口仅属于一个集合。训练集拟合标准化；验证集选择轮次；测试集仅最终评估。'})
    predrows=[]
    for r,pr,p in zip(zrows,pred,probs):
        predrows.append(dict(episode=r['episode'],end_sample=r['end_sample'],label=r['label'],prediction=int(pr),confidence=float(max(p))))
    write_csv(root/'results/test_predictions.csv',predrows)
    write_csv(root/'results/training_history.csv',logs)
    (root/'results/classification.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    return stats


class Predictor:
    def __init__(self,root):
        import mindspore as ms
        self.ms=ms; ms.set_context(mode=ms.PYNATIVE_MODE); ms.set_device('CPU')
        self.net=build_network()
        ms.load_param_into_net(self.net,ms.load_checkpoint(str(root/'models/diagnostic.ckpt')))
        self.net.set_train(False)
        v=np.load(root/'models/scaler.npz'); self.mean=v['mean']; self.scale=v['scale']
    def predict(self,feat):
        x=(feat-self.mean)/self.scale
        z=self.net(self.ms.Tensor(x[None,:],self.ms.float32)).asnumpy()[0]
        p=softmax(z); return int(p.argmax()),float(p.max())


def challenge(cfg, root):
    """分布外弱故障挑战：固定模型，不参与训练/选轮次/阈值调整。"""
    p=Predictor(root)
    X,y,rows=generate_split(cfg,'challenge_weak',20,4000000,root,weak=True)
    pred=[];conf=[]
    for x in X:
        a,b=p.predict(x);pred.append(a);conf.append(b)
    stats=classification_stats(y,np.array(pred))
    stats.update({'windows':len(y),'episodes':80,'bias_range_degC':[.1,.3],
                  'additional_noise_sigma_range_degC':[.05,.15],
                  'status':'固定checkpoint的分布外弱故障评估；没有参与模型或阈值选择。'})
    write_csv(root/'results/challenge_weak_predictions.csv',[
        dict(episode=r['episode'],end_sample=r['end_sample'],label=int(y[i]),prediction=int(pred[i]),confidence=float(conf[i]))
        for i,r in enumerate(rows)])
    (root/'results/challenge_weak.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    return stats


def simulate_one(cfg,scenario,controller,predictor,root):
    """诊断仅能看到y1/y2；T仅评分；控制使用选中传感器，不使用真值。"""
    dt=cfg['Ts_s']; N=int(cfg['duration_s']/dt)
    T=cfg['Tset_degC']; integ=(T-cfg['Tout_initial_degC'])/cfg['K_degC_per_pu']
    h1=[];h2=[]; records=[]; latched=False;bad=0;good=0;switch_time=None
    # 同一工况三个控制器共享每时刻的噪声序列，排除噪声重抽样带来的不公平。
    rng=np.random.default_rng(cfg['seed']+3000000+SCENARIOS.index(scenario))
    n1=rng.normal(0,cfg['sensor_sigma_degC'],N)
    n2=rng.normal(0,cfg['sensor_sigma_degC'],N)
    nf=rng.normal(0,cfg['fault_noise_sigma_degC'],N)
    frozen=None
    for k in range(N):
        t=k*dt; fault=t>=cfg['fault_time_s']
        tout=cfg['Tout_initial_degC']-(3 if t>=5400 else 0)-(2 if t>=9000 else 0)
        K=cfg['K_degC_per_pu']; tau=cfg['tau_s']
        if scenario=='parameter_shift' and fault: K*=.85; tau*=1.3
        y1=T+n1[k];y2=T+n2[k]
        if scenario=='bias' and fault: y1+=cfg['fault_bias_degC']
        elif scenario=='noise' and fault: y1+=nf[k]
        elif scenario=='stuck' and fault:
            if frozen is None:frozen=y1
            y1=frozen
        h1.append(y1);h2.append(y2); label=0;conf=1.0;isbad=False
        if len(h1)>=cfg['window_samples']:
            f=extract_features(h1[-cfg['window_samples']:],h2[-cfg['window_samples']:])
            if controller=='ai_pi':
                label,conf=predictor.predict(f)
                # 独立一致性守护；任何AI高置信错误不得绕过残差报警。
                isbad=(label!=0 and conf>=cfg['confidence_threshold']) or abs(float(f[0]))>1.5
            elif controller=='rule_pi':
                # 预先固定的规则：偏置/噪声/卡死阈值，未用测试集调参。
                isbad=abs(float(f[0]))>.8 or float(f[2])>.30 or (float(f[2])<.003 and float(f[3])>.015)
                label=int(isbad);conf=1.0
            bad=bad+1 if isbad else 0;good=0 if isbad else good+1
            if bad>=cfg['fault_persistence_samples']:latched=True
            if good>=cfg['recovery_persistence_samples']:latched=False
        use_reference=(controller!='plain_pi' and latched)
        if fault and use_reference and switch_time is None:switch_time=t
        measured=y2 if use_reference else y1
        error=cfg['Tset_degC']-measured
        proposed=integ+cfg['Ki_pu_per_degC_s']*dt*error
        uncon=cfg['Kp_pu_per_degC']*error+proposed
        u=float(np.clip(uncon,0,1))
        # 条件积分抗饱和：输出已到界限且误差推动继续饱和时停止积分。
        if uncon==u or (uncon>1 and error<0) or (uncon<0 and error>0):integ=proposed
        trueerror=cfg['Tset_degC']-T
        records.append(dict(t_s=t,T_true_degC=T,Tset_degC=cfg['Tset_degC'],Tout_degC=tout,
                            primary_degC=y1,reference_degC=y2,control_pu=u,
                            predicted_label=label,prediction_confidence=conf,
                            reference_selected=int(use_reference),fault_active=int(fault),
                            K_degC_per_pu=K,tau_s=tau,error_true_degC=trueerror))
        a=np.exp(-dt/tau);T=a*T+(1-a)*(tout+K*u)
    write_csv(root/'results'/f'{scenario}__{controller}.csv',records)
    post=[r for r in records if r['t_s']>=cfg['fault_time_s']]
    e=np.array([r['error_true_degC'] for r in post]); u=np.array([r['control_pu'] for r in post])
    temp=np.array([r['T_true_degC'] for r in post]);lo,hi=cfg['comfort_band_degC']
    false_s=sum(r['reference_selected']*dt for r in records if r['t_s']<cfg['fault_time_s'])
    metric=dict(scenario=scenario,controller=controller,evaluation_start_s=cfg['fault_time_s'],
                evaluation_end_s=cfg['duration_s'],rmse_degC=float(np.sqrt((e*e).mean())),
                iae_degC_h=float(np.abs(e).sum()*dt/3600),
                maximum_absolute_error_degC=float(np.abs(e).max()),
                outside_comfort_min=float(((temp<lo)|(temp>hi)).sum()*dt/60),
                input_integral_pu_h=float(u.sum()*dt/3600),
                total_variation_u=float(np.abs(np.diff(u)).sum()),
                first_reference_delay_s=None if switch_time is None else switch_time-cfg['fault_time_s'],
                pre_fault_reference_selected_s=float(false_s),
                saturated_fraction=float((u>=.999999).mean()))
    return metric


def simulate(cfg,root):
    p=Predictor(root);metrics=[]
    for s in SCENARIOS:
        for c in CONTROLLERS:
            m=simulate_one(cfg,s,c,p,root);metrics.append(m)
            print(s,c,'RMSE',round(m['rmse_degC'],4),'fallback delay',m['first_reference_delay_s'],flush=True)
    write_csv(root/'results/closed_loop_metrics.csv',metrics)
    return metrics


def make_figures(root,summary):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    font_candidates=[Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'),Path('C:/Windows/Fonts/msyh.ttc'),Path('/System/Library/Fonts/PingFang.ttc')]
    font_file=next((p for p in font_candidates if p.exists()),None)
    fp=FontProperties(fname=str(font_file)) if font_file else FontProperties(family='sans-serif')
    plt.rcParams.update({'font.family':fp.get_name(),'axes.unicode_minus':False,
                         'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#939DA8','#247D93','#C8463D']
    def save(fig,name):
        fig.savefig(root/'figures'/name,dpi=200,bbox_inches='tight',facecolor='white');plt.close(fig)
    fig,ax=plt.subplots(figsize=(6,5));cm=np.array(summary['classification']['confusion_matrix'])
    im=ax.imshow(cm,cmap='Blues'); ax.set(xticks=range(4),yticks=range(4),xticklabels=LABELS,yticklabels=LABELS,xlabel='预测类别',ylabel='真实类别',title='独立测试episode的窗口分类混淆矩阵')
    for i in range(4):
        for j in range(4):ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>cm.max()/2 else '#192E41')
    fig.colorbar(im,ax=ax,shrink=.8);save(fig,'01_confusion_matrix.jpg')
    import pandas as pd
    fig,axes=plt.subplots(3,1,figsize=(10,9),sharex=True)
    for c,color in zip(CONTROLLERS,colors):
        df=pd.read_csv(root/'results'/f'bias__{c}.csv')
        axes[0].plot(df.t_s/3600,df.T_true_degC,label=CONTROLLER_ZH[c],color=color,lw=2)
        axes[1].plot(df.t_s/3600,df.control_pu,color=color,lw=1.2)
        axes[2].plot(df.t_s/3600,df.reference_selected,color=color,lw=1.5)
    axes[0].axhline(22,ls='--',c='#263B50',lw=.8);axes[0].axhspan(20,24,color='#2A9D8F',alpha=.08)
    for ax in axes:ax.axvline(2,c='#C8463D',ls=':',lw=1.2);ax.grid(alpha=.2)
    axes[0].set(ylabel='室温真值 / ℃',title='主传感器+3℃偏置：诊断切换与闭环控制（仿真）');axes[0].legend(ncol=3,loc='lower left')
    axes[1].set(ylabel='归一化加热输入 u');axes[2].set(ylabel='选用参考传感器',xlabel='仿真时间 / h',yticks=[0,1],yticklabels=['否','是'])
    save(fig,'02_bias_closed_loop.jpg')
    fig,axes=plt.subplots(1,2,figsize=(11,4.5))
    xx=np.arange(len(SCENARIOS));width=.24
    for i,(c,color) in enumerate(zip(CONTROLLERS,colors)):
        vals=[next(m for m in summary['closed_loop'] if m['scenario']==s and m['controller']==c) for s in SCENARIOS]
        axes[0].bar(xx+(i-1)*width,[m['rmse_degC'] for m in vals],width,label=CONTROLLER_ZH[c],color=color)
        axes[1].bar(xx+(i-1)*width,[m['outside_comfort_min'] for m in vals],width,color=color)
    for ax in axes:ax.set_xticks(xx,[SCENARIO_ZH[s] for s in SCENARIOS],rotation=18,ha='right');ax.grid(axis='y',alpha=.2)
    axes[0].set(ylabel='故障/变化后RMSE / ℃',title='精度：AI与规则基线同时比较');axes[1].set(ylabel='20～24℃外时长 / min',title='舒适带外暴露（后2h）');axes[0].legend(fontsize=9)
    save(fig,'03_multi_scenario_comparison.jpg')
    challenge_file=root/'results/challenge_weak.json'
    if challenge_file.exists():
        weak=json.loads(challenge_file.read_text(encoding='utf-8'))
        fig,axes=plt.subplots(1,2,figsize=(10.5,4.5))
        for ax,stats,title in zip(axes,[summary['classification'],weak],['清晰故障：同族分布','弱故障：分布外挑战']):
            cm2=np.array(stats['confusion_matrix']);ax.imshow(cm2,cmap='Blues',vmin=0,vmax=600)
            ax.set(xticks=range(4),yticks=range(4),xticklabels=LABELS,yticklabels=LABELS,xlabel='预测类别',ylabel='真实类别',title=title+'\n宏F1='+format(stats['macro_f1'],'.3f'))
            for i in range(4):
                for j in range(4):ax.text(j,i,str(cm2[i,j]),ha='center',va='center',color='white' if cm2[i,j]>300 else '#192E41')
        fig.suptitle('固定checkpoint：高分不等于低幅故障可检出',fontsize=15,y=1.04);save(fig,'05_weak_fault_challenge.jpg')
    hist=pd.read_csv(root/'results/training_history.csv');fig,ax=plt.subplots(figsize=(7,4))
    ax.plot(hist.epoch,hist.train_loss,label='训练损失',c='#247D93');ax.plot(hist.epoch,hist.val_loss,label='验证损失',c='#C8463D');ax.set(xlabel='训练轮次',ylabel='交叉熵',title='仅由验证集选择checkpoint');ax.legend();ax.grid(alpha=.2);save(fig,'04_training_curve.jpg')


def write_summary(cfg,root,classification,metrics):
    import mindspore as ms
    summary={'artifact_status':'已运行的纯软件合成数据仿真；无实体硬件、无华为云部署、无课堂实证',
             'executed_date_utc':'2026-11-15','environment':{'python':platform.python_version(),'mindspore':ms.__version__,'numpy':np.__version__,'device':'CPU'},
             'config':cfg,'classification':classification,'closed_loop':metrics,
             'metric_definitions':{'rmse_degC':'sqrt(mean((Tset-Ttrue)^2))，t≥7200s，真值仅评分',
                                   'iae_degC_h':'sum(abs(Tset-Ttrue))*Ts/3600',
                                   'outside_comfort_min':'Ttrue不在[20,24]℃的采样时长/60',
                                   'input_integral_pu_h':'sum(u)*Ts/3600；仅归一化执行量积分，不能换算实际kWh/费用/碳排',
                                   'first_reference_delay_s':'故障发生至首次选用参考传感器；不是故障类别诊断时延',
                                   'total_variation_u':'sum(abs(diff(u)))；执行器动作代理'},
             'limitations':['合成训练与合成测试同属一阶模型族，不代表真实传感器精度或实际供热效果。',
                            '使用两路独立传感器，参考传感器在此基准中始终健康；共同失效、参考传感器故障未验证。',
                            'AI诊断+PI含一致性规则守护；结果不能归因于神经网络单独贡献。',
                            '参数变化工况K降至34℃/p.u.、最终Tout=-15℃，最大可达室温19℃，22℃目标不可达；诊断无法弥补供热能力不足。',
                            '单次固定随机种子基准，没有多次重复置信区间，未证明AI普遍优于规则。',
                            '清晰故障测试高分不等于微小故障可检出；分布外弱故障另行评估且不用于调模型。',
                            '没有学生学习增益、真实节能率、硬件实时性或华为云部署证据。']}
    checkpoint=root/'models/diagnostic.ckpt'
    challenge_path=root/'results/challenge_weak.json'
    if challenge_path.exists():summary['weak_fault_challenge']=json.loads(challenge_path.read_text(encoding='utf-8'))
    summary['checkpoint_sha256']=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    (root/'results/result_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return summary
