#!/usr/bin/env python3
"""独立从CSV复算指标，验证集合分离和训练标准化；不依赖MindSpore。"""
from pathlib import Path
import csv,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'results/result_summary.json').read_text(encoding='utf-8'))
cfg=s['config'];dt=cfg['Ts_s'];features=s['classification']['features']
def rows(name):
    with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
sets={k:rows(f'data/{k}.csv') for k in ['train','val','test']}
for a,b in [('train','val'),('train','test'),('val','test')]:
    assert not {r['episode'] for r in sets[a]} & {r['episode'] for r in sets[b]}
    assert not {r['episode_seed'] for r in sets[a]} & {r['episode_seed'] for r in sets[b]}
train=np.array([[float(r[k]) for k in features] for r in sets['train']],np.float32)
sc=np.load(ROOT/'models/scaler.npz')
assert np.allclose(train.mean(0),sc['mean'],atol=1e-6)
assert np.allclose(train.std(0),sc['scale'],atol=1e-6)
for m in s['closed_loop']:
    rr=rows(f"results/{m['scenario']}__{m['controller']}.csv")
    assert len(rr)==int(cfg['duration_s']/dt)
    post=[r for r in rr if float(r['t_s'])>=cfg['fault_time_s']]
    e=np.array([float(r['Tset_degC'])-float(r['T_true_degC']) for r in post])
    u=np.array([float(r['control_pu']) for r in post])
    T=np.array([float(r['T_true_degC']) for r in post]);lo,hi=cfg['comfort_band_degC']
    assert np.all((u>=0)&(u<=1))
    calc={'rmse_degC':float(np.sqrt((e*e).mean())),
          'iae_degC_h':float(np.abs(e).sum()*dt/3600),
          'maximum_absolute_error_degC':float(np.abs(e).max()),
          'outside_comfort_min':float(((T<lo)|(T>hi)).sum()*dt/60),
          'input_integral_pu_h':float(u.sum()*dt/3600),
          'total_variation_u':float(np.abs(np.diff(u)).sum())}
    for key,val in calc.items():assert np.isclose(val,m[key],rtol=1e-10,atol=1e-10),(m['scenario'],m['controller'],key)
    # 每一步必须严格遵循给定解析离散热模型，而不是后期画线。
    for r,rnext in zip(rr,rr[1:]):
        a=np.exp(-dt/float(r['tau_s']))
        pred=a*float(r['T_true_degC'])+(1-a)*(float(r['Tout_degC'])+float(r['K_degC_per_pu'])*float(r['control_pu']))
        assert np.isclose(pred,float(rnext['T_true_degC']),atol=1e-11)
for filename,key in [('test_predictions.csv','classification'),('challenge_weak_predictions.csv','weak_fault_challenge')]:
    rr=rows('results/'+filename);cm=np.zeros((4,4),int)
    for r in rr:cm[int(r['label']),int(r['prediction'])]+=1
    assert cm.tolist()==s[key]['confusion_matrix']
    f1=[2*cm[k,k]/(cm[k,:].sum()+cm[:,k].sum()) for k in range(4)]
    assert np.isclose(np.mean(f1),s[key]['macro_f1'])
assert hashlib.sha256((ROOT/'models/diagnostic.ckpt').read_bytes()).hexdigest()==s['checkpoint_sha256']
print('PASS: 独立episode/seed划分；仅训练集标准化；15组CSV逐步解析模型/限幅/指标；两套混淆矩阵和F1；checkpoint SHA256。')
